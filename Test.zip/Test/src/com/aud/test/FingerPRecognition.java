package com.aud.test;

import java.io.File;
import java.io.IOException;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.UnsupportedAudioFileException;

import com.musicg.fingerprint.FingerprintSimilarity;
import com.musicg.wave.Wave;

public class FingerPRecognition {

	
	public static void main(String[] args) throws UnsupportedAudioFileException, IOException { 
		 
		  String songA = "D://Gowtham//audioWork//wav//Gunsoff.wav"; 
		  String songB = "D://Gowtham//audioWork//wav//MoneyMatters.wav"; 
		  String songC = "D://Gowtham//audioWork//wav//noise.wav";
		  String songD = "D://Gowtham//audioWork//wav//Needles.wav";
		 
		  //length of audio
		 /* File file = new File(songA);;
		  AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(file);
		  AudioFormat format = audioInputStream.getFormat();
		  long frames = audioInputStream.getFrameLength();
		  double durationInSeconds = (frames+0.0) / format.getFrameRate();  
		  */
		  
		  
		  // create a wave object 
		  Wave waveA = new Wave(songA); 
		  Wave waveB = new Wave(songB); 
		  Wave waveC = new Wave(songC); 
		  Wave waveD = new Wave(songD); 
		 
		  String recordedClip = "D://Gowtham//audioWork//wav//MoneyMaters_stream.wav"; 
		  Wave waveRec = new Wave(recordedClip); 
		 
		  FingerprintSimilarity similarity; 
		   
		  // song A: 
		  similarity = waveA.getFingerprintSimilarity(waveRec); 
		  System.out.println(waveA.length());
		  System.out.println("clip is found at " 
		    + similarity.getsetMostSimilarTimePosition() + "s in " 
		    + songA+" with similarity " + similarity.getSimilarity()); 
		   
		  // song B: 
		  similarity = waveB.getFingerprintSimilarity(waveRec); 
		  System.out.println("clip is found at " 
		    + similarity.getsetMostSimilarTimePosition() + "s in " 
		    + songB+" with similarity " + similarity.getSimilarity()); 
		  
		// song C: 
		  similarity = waveC.getFingerprintSimilarity(waveRec); 
		  System.out.println("clip is found at " 
		    + similarity.getsetMostSimilarTimePosition() + "s in " 
		    + songC+" with similarity " + similarity.getSimilarity()); 
		  
		// song D: 
		  similarity = waveD.getFingerprintSimilarity(waveRec); 
		  System.out.println("clip is found at " 
		    + similarity.getsetMostSimilarTimePosition() + "s in " 
		    + songD+" with similarity " + similarity.getSimilarity()); 
		   
		  
		 } 
}
